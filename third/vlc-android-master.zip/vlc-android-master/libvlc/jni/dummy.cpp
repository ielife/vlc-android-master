/* Force ndk build system to link with c++_shared and install it */
